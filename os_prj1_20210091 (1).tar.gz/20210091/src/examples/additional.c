#include<stdio.h>
#include<stdlib.h>
#include<syscall.h>

int main(int argc,char**argv){
    
    int num=atoi(argv[1]);
    int a= atoi(argv[2]);
    int b=atoi(argv[3]);
    int c=atoi(argv[4]);

    printf("fibonacci(%d)=%d\n",num,fibonacci(num));
    printf("max_of_four_int(%d,%d,%d,%d)=%d\n",num,a,b,c,max_of_four_int(num,a,b,c));
    

    return EXIT_SUCCESS;
}