#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h" // is_user_vaddr()를 위해 추가
#include "userprog/pagedir.h" // pagedir_get_page()를 위해 추가
#include "userprog/process.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

//pintos1
static void check_address(void* addr){
  if(addr==NULL){thread_exit();}
  if(!is_user_vaddr(addr)){thread_exit();} // 커널 영역 가리키는 지 확인
  if(pagedir_get_page(thread_current()->pagedir,addr)==NULL){thread_exit();} //해당 주소가 포함된 페이지 있는지 학인

}

void halt(void){
  shutdown_power_off(); //src/devices/shutdown.c
}

tid_t exec(const char*cmd_line){
  return process_execute(cmd_line);
}

int wait(tid_t pid){
  return process_wait(pid);
}

int write(int fd,const void* buffer,unsigned int size){
  if(fd==1){
    putbuf(buffer,size);
    return size;
  }
  return -1;
}

void exit(int status){
  struct thread *t=thread_current();
  printf("%s: exit(%d)\n",thread_name(),status);
  t->exit_status=status;
  thread_exit();
}

int read(int fd,void *buffer,unsigned int size){

  if(fd==0){
    unsigned int i;
    for(i=0;i<size;i++){
      uint8_t c=input_getc();
      *((uint8_t*)buffer + i) = c;
      if(c=='\0') break;
    }
    return i;
  }else{
    return -1;
  }
}

int max_of_four_int(int a,int b,int c,int d){
  int max_val=a;
  if(b>max_val) max_val=b;
  if(c>max_val) max_val=c;
  if(d>max_val) max_val=d;
  return max_val;
}

int fibonacci(int n){
  if(n<=1) return n;
  else{
    int a=0, b=1,temp;
    for(int i=2;i<=n;i++){
      temp=a+b;
      a=b;
      b=temp;
    }
    return b;
  }
}


static void syscall_handler(struct intr_frame *f UNUSED) {
  switch(*(int32_t*)(f->esp)){
    case SYS_HALT:
    halt();                   /* Halt the operating system. */
    break;
    case SYS_EXIT:
    check_address(f->esp+4);
    exit(*(int*)(f->esp+4));                   /* Terminate this process. */
    break;
    case SYS_EXEC:
    check_address(f->esp+4);
    f->eax=exec((char*)*(uint32_t*)(f->esp+4));             /* Start another process. */
    break;
    case SYS_WAIT: 
    f->eax = wait(*(uint32_t*)(f->esp+4));                  /* Wait for a child process to die. */
    break;
    case SYS_CREATE:                 /* Create a file. */
    break;
    case SYS_REMOVE:                 /* Delete a file. */
    break;
    case SYS_OPEN:                   /* Open a file. */
    break;
    case SYS_FILESIZE:               /* Obtain a file's size. */
    break;
    case SYS_READ: 
    check_address(f->esp+4);
    check_address(f->esp+8);
    check_address(f->esp+12); 
    f->eax=read((int)*(uint32_t*)(f->esp+4), (void*)*(uint32_t*)(f->esp+8),
					(unsigned)*(uint32_t*)(f->esp+12));                /* Read from a file. */
    break;
    case SYS_WRITE: 
    int fd = *(int*)(f->esp + 4);
    void *buffer = *(void**)(f->esp + 8);
    unsigned size = *(unsigned*)(f->esp + 12);

    check_address(buffer);
    f->eax=write(fd, buffer,size);
    /* Write to a file. */
    break;
    case SYS_SEEK:                   /* Change position in a file. */
    break;
    case SYS_TELL:                   /* Report current position in a file. */
    break;
    case SYS_CLOSE:                  /* Close a file. */
    break;
    case SYS_MAX_OF_FOUR_INT:
    {
      int a= *(int*)(f->esp+4);
      int b= *(int*)(f->esp+8);
      int c= *(int*)(f->esp+12);
      int d=*(int*)(f->esp+16);
      f->eax=max_of_four_int(a,b,c,d);
      break;
  }
  case SYS_FIBONACCI:
  {
    int n=*(int *)(f->esp+4);
    f->eax=fibonacci(n);
    break;
  }
  //printf ("system call! %d\n", *(int32_t*)(f->esp));
  //thread_exit ();
}
}

