#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h" // is_user_vaddr()를 위해 추가
#include "userprog/pagedir.h" // pagedir_get_page()를 위해 추가
#include "userprog/process.h"
#include "devices/shutdown.h" // for shutdown_power_off
#include "filesys/filesys.h"  // for filesys_create, filesys_open, filesys_remove
#include "filesys/file.h"     // for file_read, file_write, file_length, file_seek, file_tell
#include "devices/input.h"    // for input_getc

static void syscall_handler (struct intr_frame *);
struct lock filesys_lock;

void
syscall_init (void) 
{
  lock_init(&filesys_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

//pintos1
static void check_address(void* addr){
  if(addr==NULL){exit(-1);}
  if(!is_user_vaddr(addr)){exit(-1);} // 커널 영역 가리키는 지 확인
  if(pagedir_get_page(thread_current()->pagedir,addr)==NULL){exit(-1);} //해당 주소가 포함된 페이지 있는지 학인

}

void halt(void){
  shutdown_power_off(); //src/devices/shutdown.c
}


tid_t exec(const char*cmd_line){
  return process_execute(cmd_line);
}

int wait(tid_t pid){
  return process_wait(pid);
}

int write(int fd,const void* buffer,unsigned int size){
  int i;
  if(fd<=0||fd>=FDTABLE_SIZE) exit(-1);
  if(fd==1){
    putbuf(buffer,size);
    //lock_release(&filesys_lock);
    return size;
  }else{
    lock_acquire(&filesys_lock);
    struct file*f=get_process_file(fd);
    lock_release(&filesys_lock);
    if(f==NULL){
      exit(-1);
    }
    //파일 객체의 락 사용
    lock_acquire(&f->file_lock);
    i=file_write(f,buffer,size);
    lock_release(&f->file_lock);
    return i;
  }
}

void exit(int status){
  struct thread *t=thread_current();
  printf("%s: exit(%d)\n",thread_name(),status);
  t->exit_status=status;
  thread_exit();
}

int read(int fd,void *buffer,unsigned int size){
  unsigned int i;
  if(fd<0||fd==1||fd>=FDTABLE_SIZE) exit(-1);
  if(fd==0){
    for(i=0;i<size;i++){
      uint8_t c=input_getc();
      *((uint8_t*)buffer + i) = c;
      if(c=='\0') break;
    }
  }else{
      lock_acquire(&filesys_lock);
      struct file*f=get_process_file(fd);
      lock_release(&filesys_lock);
      if(f==NULL){
        exit(-1);
      }
      lock_acquire(&f->file_lock);
      i=file_read(f,buffer,size);
      lock_release(&f->file_lock);
    }
    //lock_release(&filesys_lock);
    return i;
}

int max_of_four_int(int a,int b,int c,int d){
  int max_val=a;
  if(b>max_val) max_val=b;
  if(c>max_val) max_val=c;
  if(d>max_val) max_val=d;
  return max_val;
}

int fibonacci(int n){
  if(n<=1) return n;
  else{
    int a=0, b=1,temp;
    for(int i=2;i<=n;i++){
      temp=a+b;
      a=b;
      b=temp;
    }
    return b;
  }
}

//pintos 2
int open(const char*file){
  int fd;
  struct file*f;
  if(file==NULL) exit(-1);
  lock_acquire(&filesys_lock);
  f=filesys_open(file);
  if(f==NULL){
    lock_release(&filesys_lock);
    return -1;
  }
  fd=add_process_file(f);
  lock_release(&filesys_lock);
  return fd;
}

bool create(const char*file,unsigned size){
  bool success;
  if(file==NULL) exit(-1);
  lock_acquire(&filesys_lock);
  success=filesys_create(file,size);
  lock_release(&filesys_lock);

  return success;
}

bool remove(const char*file){
 bool success;
 if(file==NULL) exit(-1);
  
 lock_acquire(&filesys_lock);
 success = filesys_remove(file);
 lock_release(&filesys_lock);

 return success;
}

void close(int fd){
  lock_acquire(&filesys_lock);
  close_process_file(fd);
  lock_release(&filesys_lock);
}

int filesize(int fd){
  int length;
  lock_acquire(&filesys_lock);
  struct file*f=get_process_file(fd);
  if(f==NULL) {
    lock_release(&filesys_lock);
    exit(-1);
  }
  lock_release(&filesys_lock);
  lock_acquire(&f->file_lock);
  length=file_length(f);
  lock_release(&f->file_lock);
  return length;
}

void seek(int fd,unsigned int position){
  lock_acquire(&filesys_lock);
  struct file*f=get_process_file(fd);
  if(f==NULL){
    lock_release(&filesys_lock);
    exit(-1);
  }
  lock_release(&filesys_lock);
  lock_acquire(&f->file_lock);
  file_seek(f,position);
  lock_release(&f->file_lock);
}

unsigned int tell(int fd){
  unsigned int position;
  lock_acquire(&filesys_lock);
  struct file*f=get_process_file(fd);
  if(f==NULL){
    lock_release(&filesys_lock);
    exit(-1);
  }
  lock_release(&filesys_lock);
  lock_acquire(&f->file_lock);
  position=file_tell(f);
  lock_release(&f->file_lock);

  return position;
}


static void syscall_handler(struct intr_frame *f UNUSED) {
  check_address(f->esp);
  switch(*(int32_t*)(f->esp)){
    case SYS_HALT:
    halt();                   /* Halt the operating system. */
    break;
    case SYS_EXIT:
    check_address(f->esp+4);
    exit(*(int*)(f->esp+4));                   /* Terminate this process. */
    break;
    case SYS_EXEC:{
    check_address(f->esp+4);
    char*filename=(char*)*(uint32_t*)(f->esp+4);
    check_address(filename);
    size_t i=0;
    //파일 이름 문자열 전체 검사
    while(true){
      check_address(filename+i);
      if(*(filename+i)=='\0') break;
      i++;
    }
    tid_t tid=exec(filename);
    if(tid==TID_ERROR){
      f->eax=-1;
      break;
    }
    struct thread *child=get_child_thread(tid);
    if(child==NULL){
      f->eax=-1;
      break;
    }
    //자식이 로드 끝날 때까지 대기
    sema_down(&child->load_sem);

    if(child->load_flag==false){
      f->eax=-1;
    }else{
      f->eax=tid;
    }
                 
    break;
  }
    case SYS_WAIT: 
    f->eax = wait(*(uint32_t*)(f->esp+4));                  /* Wait for a child process to die. */
    break;
    case SYS_CREATE:{                 /* Create a file. */
    check_address(f->esp+4);
    check_address(f->esp+8);
    char *filename=(char*)*(uint32_t*)(f->esp+4);

    check_address(filename);
    size_t i=0;
    while(true){      check_address(filename+i);
      if(*(filename+i)=='\0') break;
      i++;
    }
    f->eax=create(filename,*(uint32_t*)(f->esp+8));
    break;
  }
    case SYS_REMOVE:{                 /* Delete a file. */
    check_address(f->esp+4);
    char* filename=(char*)*(uint32_t*)(f->esp+4);
    check_address(filename);
    size_t i=0;
    while(true){
      check_address(filename+i);
      if(*(filename+i)=='\0') break;
      i++;
    }
    f->eax = remove(filename);
    break;
  }
    case SYS_OPEN:{                   /* Open a file. */
    check_address(f->esp+4);
    char*filename=(char*)*(uint32_t*)(f->esp+4);
    check_address(filename);
    size_t i=0;
    while(true){
      check_address(filename+i);
      if(*(filename+i)=='\0') break;
      i++;
    }
    f->eax = open(filename);
    break;
  }
    case SYS_FILESIZE:               /* Obtain a file's size. */
    check_address(f->esp+4);
    f->eax = filesize(*(uint32_t*)(f->esp+4));
    break;
    case SYS_READ:{ 
    check_address(f->esp+4);
    check_address(f->esp+8);
    check_address(f->esp+12);
    
    int fd_read=*(int*)(f->esp+4);
    void*buffer_read=*(void**)(f->esp+8);
    unsigned size_read=*(unsigned*)(f->esp+12);

    //버퍼 영역 전체 검사
    for(size_t i=0;i<size_read;i++){
      check_address((uint8_t*)buffer_read+i);
    }
    f->eax=read(fd_read,buffer_read,size_read);                /* Read from a file. */
    break;
  }
    case SYS_WRITE:{ 
    check_address(f->esp + 4); 
    check_address(f->esp + 8);
    check_address(f->esp + 12);

    int fd = *(int*)(f->esp + 4);
    void *buffer = *(void**)(f->esp + 8);
    unsigned size = *(unsigned*)(f->esp + 12);

    for(size_t i=0;i<size;i++){
      check_address((uint8_t*)buffer+i);
    }
    f->eax=write(fd, buffer,size);
    /* Write to a file. */
    break;
  }
    case SYS_SEEK:{                   /* Change position in a file. */
    check_address(f->esp+4);
    check_address(f->esp+8);
    seek((int)*(uint32_t*)(f->esp+4), (unsigned)*(uint32_t*)(f->esp+8));
    break;
    }
    case SYS_TELL:                   /* Report current position in a file. */
    check_address(f->esp+4);
    f->eax = tell((int)*(uint32_t*)(f->esp+4));
    break;
    case SYS_CLOSE:                  /* Close a file. */
    check_address(f->esp+4);
    close(*(uint32_t*)(f->esp+4));
    break;
    case SYS_MAX_OF_FOUR_INT:
    {
      check_address(f->esp+4); 
      check_address(f->esp+8); 
      check_address(f->esp+12); 
      check_address(f->esp+16);

      int a= *(int*)(f->esp+4);
      int b= *(int*)(f->esp+8);
      int c= *(int*)(f->esp+12);
      int d=*(int*)(f->esp+16);
      f->eax=max_of_four_int(a,b,c,d);
      break;
  }
  case SYS_FIBONACCI:
  {
    int n=*(int *)(f->esp+4);
    f->eax=fibonacci(n);
    break;
  }
  //printf ("system call! %d\n", *(int32_t*)(f->esp));
  //thread_exit ();
}

}

